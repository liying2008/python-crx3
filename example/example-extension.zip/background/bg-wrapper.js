try {
  importScripts('background.js');
} catch (error) {
  console.error(error);
}
